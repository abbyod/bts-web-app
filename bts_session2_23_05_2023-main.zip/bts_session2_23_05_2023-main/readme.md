# bts_session2_23_05_2023

Let's get our hands dirty today! 💪

Find in the repository's root the session.pdf file with the slides.
